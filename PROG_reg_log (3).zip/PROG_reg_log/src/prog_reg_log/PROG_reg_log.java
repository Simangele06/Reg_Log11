package prog_reg_log;

import java.util.Scanner;

public class PROG_reg_log {
//SCANNER FOR USER INPUT
    static Scanner scanner = new Scanner(System.in);
//FLAG TO CHECK IF THE USER HAS FEGISTERED.
    static boolean Register = false;
 //DECLARATION.
    static String password = "";
    static String username = "";
    static String firstname = "";
    static String lastname = "";

    public static void main(String[] args) {
        
//THIS WILL RUN FOREVER UNTIL THE LOOP IS SUCCESSFUL.
        while (true) {

            System.out.println("======MAIN MENU======");
            System.out.println("1. Register");
            System.out.println("2. Login");

            System.out.print("Choose option: ");
            int option = scanner.nextInt();
            scanner.nextLine();

            if (option == 1) {
                register();
            } 
            else if (option == 2) {
                login();
                 break; //STOP THE LOGIN OPTION AFTER BEING SUCCESSFUL.
            }
        }
    }

    // ======= REGISTER ========
    public static void register() {
//THE MAXIMUM LENGTH OF THE USERNAME THAT IS ALLOWED.
        final int USERNAME_LENGTH = 5;

        while (true) {

            System.out.println("=====REGISTERING=====");

            System.out.print("Enter First Name: ");
            firstname = scanner.nextLine();

            System.out.print("Enter Last Name: ");
            lastname = scanner.nextLine();
             System.out.println("");
             System.out.println("______USERNAME______");
            //CONDITIONS OF USERNAME
            System.out.println("Username must contain an (_)");
            System.out.println("Username must not be more than 5 characters");
            
            System.out.print("Enter username: ");
            username = scanner.nextLine();
//CHECKS IF DETAILS MATCHES WITH WHAT IS NEEDED.
            if (username.length() > USERNAME_LENGTH || !username.contains("_")) { // IF THE USERNAME IS LONG OR DOES NOT HAVE "_" IT IS INVALID.
                System.out.println("Username is not correctly formatted; please ensure that your username contains an underscore and is no more than five characters in length.");
            } else {       //IF THE UDERNAME IS CAPTURED CORRECT IT WILL BE SUCCESSFUL.
                System.out.println("Username successful captured.");
                break; //THIS STOPS THE USERNAME LOOP WHEN EVERYTHING IS CAPTURED CORRECT.
            }
        } 
        
        System.out.println(""); // SPACE BETWEEN THE USERNAME AND PASSWORD.
        System.out.println("_______PASSWORD_______");
//THE MAXIMUM LENGTH OF THE PASSWORD THAT IS ALLOWED.
        final int PASSWORD_LENGTH = 8;

        boolean hasUpperCase;     // checks if password has a capital
        boolean hasNumber;       // checks if password has a number
        boolean hasSpecialCase; // checks if password has a special

        while (true) {
//THIS IS SET AS FALSE BECAUSE WE HAVE NOT CHECKED ANYTHING. IT WILL BECOME TRUE ONCE THE PASSWORD IS CAPTURED AS SUCCESSFUL.
            hasUpperCase = false;
            hasNumber = false;
            hasSpecialCase = false;
  // CONDITIONS FOR PASSWORD.          
            System.out.println("PASSWORD MUST HAVE: ");
            System.out.println("-At least 8 characters long.");
            System.out.println("-Contain a capital letter.");
            System.out.println("-Contain a number.");
            System.out.println("-Contain a special character.");

            System.out.print("Enter password: ");
            password = scanner.nextLine();
// THIS GOES THROUGH THE PASSWORD ONE CHARACTER AT THE TIME TO CHECK IF IF MEETS THE CONDITIONS.
            for (int i = 0; i < password.length(); i++) {
                char ch = password.charAt(i);
 // IF CAPITAL LETTER IS FOUND THIS WILL BE SET AS TRUE.
                if (Character.isUpperCase(ch)) hasUpperCase = true;
 // IF NUMBER IS FOUND THIS WILL BE SET AS TRUE.               
                if (Character.isDigit(ch)) hasNumber = true; 
 // IF SPECIAL CHARACTER IS FOUND THIS WILL BE SET AS TRUE.               
                if (!Character.isLetterOrDigit(ch)) hasSpecialCase = true;
            }
// CHECKS IF DETAILS MATCHES WITH WHAT IS NEEDED.
            if (password.length() < PASSWORD_LENGTH || !hasUpperCase || !hasNumber || !hasSpecialCase) {    //IF THE CONDITION DO NOT MATCH THEN THE PASSWORD IS INVALID.
                System.out.println("Password is not correctly formatted; please ensure that the password contains at least eight characters, a capital letter, a number and a special character.");
            } else {      //IF THE CONDITION MATCH THEN THE PASSWORD IS VALID.
                System.out.println("Password successful captured.");
                break; // STOPS THE LOOP FOR THE PASSWORD WHEN EVERYTHING IS SUCCESSFUL
            }
        }
        System.out.println(""); // SPACE BETWEEN PASSWORD AND CELLPHONE.
        System.out.println("_______CELLPHONE NUMBER_______");

// DECLARATION.
        String plus = "+";
        String cellphoneNum;
        String interDigitCode;
//THE MAXIMUM LENGTH OF THE CELLPHONE THAT IS ALLOWED.
        final int CELLPHONE_LENGTH = 10;

        do {
            //CONDITION FOR INTERNATIONAL CODE
            System.out.println("Cell phone number MUST contain international digit code. EXAMPLE:'+27'");
            System.out.print("Enter international digit code: ");
            interDigitCode = scanner.nextLine();

            //CONDITION FOR CELLPHONE NUMBER.
            System.out.println("Cell phone number MUST contain no more than ten characters.");
            System.out.print("Enter your cellphone Number: ");
            cellphoneNum = scanner.nextLine();

            if (cellphoneNum.length() > CELLPHONE_LENGTH || !interDigitCode.contains(plus)) {  //IF THE CONDITION DO NOT MATCH THEN THE CELLPHONE NUMBER IS INVALID.
                System.out.println("Cell phone number incorrectly formatted or does not contain international code. ");
            }
// CHECKS IF DETAILS MATCHES WITH WHAT IS NEEDED.
        } while (cellphoneNum.length() > CELLPHONE_LENGTH || !interDigitCode.contains(plus));   //IF THE CONDITION DO NOT MATCH THEN THE CELLPHONE NUMBER IS INVALID.
            System.out.println("Cell phone number successful added.");
            System.out.println("YOU ARE DONE REGISTERING!!!");

        Register = true;
    }

    // ======== LOGIN ========
    public static boolean login() {
        System.out.println("");  //SPACE
        System.out.println("==== LOGIN ====");
// CHECK IF THE USER HAS REGISTERED.
        if (!Register) {
            System.out.println("You have not registered. Please register first.");
             return false; // STOP LOGIN PROCESS IF THE USER IS NOT REGISTERED.
        }

        System.out.print("Welcome " + firstname + " " + lastname); 
         System.out.println(" it is great to see you again!"); 
//WILL KEEP ASKING TO ENTER CORRECT LOGIN DETAILS         
        while (true) {

            System.out.print("Enter username: ");
            String loginUser = scanner.nextLine();

            System.out.print("Enter password: ");
            String loginPass = scanner.nextLine(); 
// CHECKS IF DETAILS MATCHES WITH WHAT IS NEEDED.
          if (loginUser.equals(username) && loginPass.equals(password)) {    //IF THE CONDITION MATCH THEN THE LOGIN DETAILS IS VALID.
                System.out.println("Login successful");
               return true; 
            } else {     //IF THE CONDITION DO NOT MATCH THEN THE LOGIN DETAILS IS INVALID.
                System.out.println("Wrong username or password. Try again.");   // THIS WILL KEEP ON LOOPING UNTIL THE LOGIN DETAILS ARE TRUE.
                
            }
        }
    }
}